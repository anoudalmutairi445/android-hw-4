package com.example.moviesdisplay;

import java.io.Serializable;

public class Movies implements Serializable {
    private String title;
    private int image;
    private int pgrate;
    private int rdate;

    public Movies(String title, int image, int pgrate, int rdate) {
        this.title = title;
        this.image = image;
        this.pgrate = pgrate;
        this.rdate = rdate;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getPgrate() {
        return pgrate;
    }

    public void setPgrate(int pgrate) {
        this.pgrate = pgrate;
    }

    public int getRdate() {
        return rdate;
    }

    public void setRdate(int rdate) {
        this.rdate = rdate;
    }

}
