package com.example.moviesdisplay;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Movies> moviee = new ArrayList<>();

        Movies m1 = new Movies("Enola Holmes",R.drawable.enloa,13,2020);
        Movies m2 = new Movies("The Conjuring",R.drawable.theconjuring,16,2013);
        Movies m3 = new Movies("Jumanji", R.drawable.jumanji,13,1995);
        Movies m4 = new Movies("La La Land",R.drawable.lalaland,13, 2016);
        Movies m5 = new Movies("Little Women",R.drawable.thelittlewomen,7,1994);
        Movies m6 = new Movies("The Grinch",R.drawable.thegrinch,7,2018);

        moviee.add(m1);
        moviee.add(m2);
        moviee.add(m3);
        moviee.add(m4);
        moviee.add(m5);
        moviee.add(m6);


        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);

        MAdapt pa = new MAdapt(moviee,this);
        rv.setAdapter(pa);



    }
}