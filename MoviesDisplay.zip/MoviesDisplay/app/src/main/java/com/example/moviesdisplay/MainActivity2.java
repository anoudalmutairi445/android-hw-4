package com.example.moviesdisplay;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle aie = getIntent().getExtras();
        Movies p = (Movies) aie.getSerializable("movie");

        ImageView img = findViewById(R.id.pix);
        TextView name = findViewById(R.id.namee);
        TextView pg = findViewById(R.id.pgr);
        TextView rdd = findViewById(R.id.rd);


        img.setImageResource(p.getImage());
        name.setText(p.getTitle());
        pg.setText(p.getPgrate()+"");
        rdd.setText(p.getRdate()+"");

    }
}